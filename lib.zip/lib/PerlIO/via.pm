package PerlIO::via;
our $VERSION = '0.01';
use XSLoader ();
XSLoader::load 'PerlIO::via';
1;
__END__

