package IO::Stringy;

use vars qw($VERSION);
$VERSION = substr q$Revision: 2.108 $, 10;

1;
__END__


